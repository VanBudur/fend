import './styles/resets.css'
import './styles/base.css'
import './styles/footer.css'
import './styles/form.css'
import './styles/header.css'

import { checkForName } from './js/nameChecker'
import { handleSubmit,showResult } from './js/formHandler'

console.log(checkForName,showResult);

alert("I EXIST")
console.log("CHANGE!!");
